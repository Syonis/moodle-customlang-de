<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from ---
 *
 * @package    report
 * @subpackage stats
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['eventuserreportviewed'] = 'Nutzerstatistik gesehen';
$string['nocapability'] = 'Kein Zugriff auf die Nutzerstatistik';
$string['page-report-stats-user'] = 'Nutzer- Kursstatistik-Bericht';
$string['privacy:metadata:roleid'] = 'Rollen-ID des Nutzers';
$string['privacy:metadata:statssummary'] = 'Aufzeichnung von grundlegenden Aktivitäten des Nutzers im Kurs';
