<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from ---
 *
 * @package    block
 * @subpackage activity_results
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['config_use_groups'] = 'Gruppen statt Teilnehmer anzeigen? (nur möglich, wenn Gruppen von der Aktivität unterstützt werden)';
$string['defaultnameoptions_desc'] = 'Wie sollen die Teilnehmer identifiziert werden?';
$string['defaultshowgroups_desc'] = 'Gruppen statt Teilnehmer anzeigen (nur wenn die Aktivität Gruppen unterstützt)';
