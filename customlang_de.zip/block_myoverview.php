<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from ---
 *
 * @package    block
 * @subpackage myoverview
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['availablegroupings_desc'] = 'Kursfilter, die den Nutzern zur Auswahl stehen. Wenn keine ausgewählt sind, werden alle Kurse angezeigt.';
$string['defaulttab_desc'] = 'Der ausgewählte Tab wird Nutzern angezeigt, wenn sie zum ersten Mal ihre Kursübersicht sehen. Der zuletzt geöffnete Tab wird angezeigt, wenn Nutzer zu ihrer Kursübersicht zurückkehren.';
$string['layouts_help'] = 'Layouts für die Kursübersicht, die den Nutzern zur Auswahl stehen. Wenn keine ausgewählt sind, wird das Kartenlayout verwendet.';
