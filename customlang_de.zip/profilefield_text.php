<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from ---
 *
 * @package    profilefield
 * @subpackage text
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['privacy:metadata:profilefield_text:data'] = 'Texteingabe im Nutzerprofilfeld';
$string['privacy:metadata:profilefield_text:dataformat'] = 'Format der Texteingabe der gespeicherten Nutzerdaten';
$string['privacy:metadata:profilefield_text:tableexplanation'] = 'Zusätzliche Nutzerinformationen';
$string['privacy:metadata:profilefield_text:userid'] = 'Nutzer-ID des Benutzers, dessen Daten vom Texteingabe-Plugin gespeichert wurden';
