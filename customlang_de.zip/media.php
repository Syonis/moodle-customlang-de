<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from ---
 *
 * @package    core
 * @subpackage media
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['mediaformats_desc'] = 'Wenn die MediaPlayer aktiviert sind, können Mediendateien einfach eingebettet werden, u.z. durch Nutzung des Filters \'Multimedia-Plugins\' (falls aktiviert), außerdem durch Hochladen als \'Datei\' bzw. Verlinken einer externen Ressource als \'Link/URL\'. Wenn die MediaPlayer nicht aktiviert sind, werden die Mediendateien nicht eingebettet. Nutzer können die Dateien herunterladen oder den URLs zu den externen Ressourcen folgen. Wenn zwei MediaPlayer das gleiche Format unterstützen, können beide aktiviert werden, um das Abspielen auf unterschiedlichen digitalen Endgeräten zu ermöglichen oder verschiedene Dateiformate alternativ anzubieten.';
