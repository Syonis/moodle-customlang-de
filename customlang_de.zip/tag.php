<?php

// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Local language pack from ---
 *
 * @package    core
 * @subpackage tag
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */

defined('MOODLE_INTERNAL') || die();

$string['owner'] = 'Eigentümer';
$string['privacy:metadata:tag:userid'] = 'Benutzer, der den Tag angelegt hat';
$string['privacy:metadata:taginstance:tiuserid'] = 'Wo gemeinsam genutzter Inhalt von Benutzern individuell gekennzeichnet werden kann, wird der Eigentümer des Tags gespeichert.';
$string['responsiblewillbenotified'] = 'Verantwortlicher Benutzer wird benachrichtigt';
$string['tagauthor'] = 'Tag-Autor';
